/********* definitions.c ********
    Student Name 	= Abubakr Mohammed
    Student Number = 101287262
*/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "a2_nodes.h"
#include "a2_functions.h"

// Your solution goes here

/*
   Function that creates a new user and adds it to a sorted (ascending order) linked list at
   the proper sorted location. Return the head of the list.
*/
user_t *add_user(user_t *users, const char *username, const char *password)
{
   user_t *user = malloc(sizeof(user_t));
   assert(user != NULL);
   strcpy(user->username, username);
   strcpy(user->password, password);
   user->friends = NULL;
   user->posts = NULL;

   if (users == NULL || strcmp(user->username, users->username) < 0){
      user->next = users;
      return user;
   }
   // assign new pointer temp to list and check if the new node is greater then the head node and to make sure list is not empty.
   user_t *temp = users;
   while (temp->next != NULL && strcmp(user->username, temp->next->username) > 0)
   {
      temp = temp->next;
   }
   user->next = temp->next;
   temp->next = user;
   return users;
}
/*
   Function that searches if the user is available in the database
   Return a pointer to the user if found and NULL if not found.
*/
user_t *find_user(user_t *users, const char *username)
{
   assert(users != NULL);

   for (; users != NULL && strcmp(users->username, username) != 0; users = users->next)
   {
   }
   return users;
}
/*
   Function that creates a new friend's node.
   Return the newly created node.
*/
friend_t *create_friend(const char *username)
{
   friend_t *friend = malloc(sizeof(friend_t));
   assert(friend != NULL);

   strcpy(friend->username, username);
   return friend;
}

/*
   Function that links a friend to a user. The friend's name should be added into
   a sorted (ascending order) linked list.
*/
void add_friend(user_t *user, const char *friend)
{
   friend_t *new_friend = create_friend(friend);

   if (user->friends== NULL || strcmp(friend, user->friends->username) < 0){ // check to see if user has 0 friends and to check the sorted list of usernames of friends
      new_friend->next = user->friends;
      user->friends = new_friend;
   }
   else{
      friend_t *current = user->friends;
      while (current->next != NULL && strcmp(new_friend->username, current->next->username) > 0)
      {
         current = current->next;
      }
      new_friend->next = current->next;
      current->next = new_friend;
   }
}

/*
   Function that removes a friend from a user's friend list.
   Return true if the friend was deleted and false otherwise.
*/
#include <stdbool.h>
_Bool delete_friend(user_t *user, char *friend_name)
{
   friend_t *current = user->friends;
   friend_t *removed = NULL;

   while(current != NULL && strcmp(current->username, friend_name)!= 0){
      removed = current;
      current = current->next;
   }
   if (current != NULL){

      if(removed != NULL){
         removed->next = current->next;
      }
      else{
         user->friends = current->next;
      }
      free(current); // free up the value assigned to by pointer
      return true;
   }
   else{
      printf("Friend not found, invalid input\n");
      return false;
   }
}

/*
   Function that creates a new user's post.
   Return the newly created post.
*/
post_t *create_post(const char *text)
{
   post_t *post = malloc(sizeof(post_t));
   assert(post->content != NULL);
   strcpy(post->content, text);
   post->next = NULL;
   return post;
}

/*
   Function that adds a post to a user's timeline. New posts should be added following
   the stack convention (LIFO) (i.e., to the beginning of the Posts linked list).
*/
void add_post(user_t *user, const char *text)
{
   post_t *new_post = create_post(text);
   new_post->next = user->posts;
   user->posts = new_post;
}

/*
   Function that removes a post from a user's list of posts.
   Return true if the post was deleted and false otherwise.
*/
_Bool delete_post(user_t *user, int number)
{
   post_t *current = user->posts;
   int count = 0;
   if (number - 1 == 0){ // if user has only one post in which all posts are removed
      user->posts = current->next;
      free(current);
      printf("Post %d was deleted successfully!\n", number);
      return true;
   }
   while (current != NULL && count < number - 2){
      current = current->next;
      count++;
   }
   if (current == NULL || current->next == NULL){
      printf("Invalid post's number: \n");
      return false;
   }
   post_t *temp = current->next->next;
   free(current->next);
   current->next = temp;
   printf("Post no %d was deleted successfully!\n", number);
   return true;
}

/*
   Function that  displays a specific user's posts
*/
void display_user_posts(user_t *user)
{
   int counter = 1;
   post_t *post = user->posts;
   if (post == NULL)
   {
      printf("No posts available for %s.\n", user->username);
   }
   while (post != NULL)
   {
      printf("%d- %s: %s\n", counter, user->username, post->content);
      post = post->next;
      counter++;
   }
}

/*
   Function that displays a specific user's friends
*/
void display_user_friends(user_t *user)
{
   printf("List of %s's friends: \n", user->username);
   int count = 1;
   friend_t *buddy = user->friends;
   if (buddy == NULL){
   printf("No friends avaiable for %s\n", user->username);
   }
   while (buddy != NULL){
      printf("%d- %s\n", count, buddy->username);
      buddy = buddy->next;
      count++;
   }

}
/*
   Function that displays all the posts of 2 users at a time from the database.
   After displaying 2 users' posts, it prompts if you want to display
   posts of the next 2 users.
   If there are no more post or the user types “n” or “N”, the function returns.
*/
void display_all_posts(user_t *users)
{

   int count = 0;
   char choice;
   user_t *user = users;
   while(user != NULL){
      if (count < 2){
         display_user_posts(user);
         user = user->next;
         count++;
      }
      else
      {
         printf("\n Do you want to display the next 2 users posts (Y/N):  ");
         scanf("%s", &choice);
         if (choice == 'Y' || choice == 'y'){
            count = 0; // resets back to if statement
            printf("\n\n");
         }
         else if (choice == 'N' || choice == 'n'){
            return;
         }
         else{
            printf("Invalid input !\n");
         }
      }
   }
}
/*
Function displays the friend's posts
*/
void display_friends_posts(friend_t *friend) {
    if (friend->posts != NULL || !(*(friend->posts))) {
        printf("No posts available for %s\n", friend->username);
        return;
    }

    int num = 1;
    post_t *current = *(friend->posts);
    while (current != NULL) {
        printf("%d- %s: %s\n", num++, friend->username, current->content);
        current = current->next;
    }
}
/*
   Fucntion that free all users from the database before quitting the application.
*/
void teardown(user_t *users)
{
   while (users != NULL)
   {
      friend_t *tempf = users->friends;
      post_t *temp = users->posts;
      user_t *p = users;
      users = users->next;
      free(tempf);
      free(temp);
      free(p);
   }
}

/*
   Function that prints the main menu with a list of options for the user to choose from
*/
void print_menu()
{  
   printf("***************************\n");
   printf("\t      Main Menu      \n");
   printf("***************************\n");
   printf("1. Register a new User\n");
   printf("2. Login with existing user's informtation \n");
   printf("3. Exit\n");
}

/*
   ******** DONT MODIFY THIS FUNCTION ********
   Function that reads users from the text file.
   IMPORTANT: This function shouldn't be modified and used as is
   ******** DONT MODIFY THIS FUNCTION ********
*/
user_t *read_CSV_and_create_users(FILE *file, int num_users)
{
    user_t *users = NULL;
    char buffer[500];
    fgets(buffer, sizeof(buffer), file); // Read and discard the header line
    int count = 0;
    for (int i = 0; i < num_users; i++)
    {
        fgets(buffer, sizeof(buffer), file);
        buffer[strcspn(buffer, "\r\n")] = 0; // Remove newline characters

        char *token = strtok(buffer, ",");
        char *token2 = strtok(NULL, ",");
        users = add_user(users, token, token2);
        char *username = token;

        token = strtok(NULL, ",");

        user_t *current_user = users;
        for (; current_user != NULL && strcmp(current_user->username, username) != 0; current_user = current_user->next)
            ;

        while (token != NULL && strcmp(token, ",") != 0 && count < 3)
        {
            if (strcmp(token, " ") != 0)
            {
                add_friend(current_user, token);
            }
            token = strtok(NULL, ",");
            count++;
        }
        count = 0;

        // token = strtok(NULL, ",");
        while (token != NULL && strcmp(token, ",") != 0)
        {
            add_post(current_user, token);
            token = strtok(NULL, ",");
        }
    }
    return users;
}
