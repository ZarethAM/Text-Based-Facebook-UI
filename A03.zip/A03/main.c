/********* main.c ********
    Student Name 	= Abubakr Mohammed
    Student Number	= 101287262
*/

// Includes go here
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "a2_nodes.h"
#include "a2_functions.h"

int main()
{
    /******** DONT MODIFY THIS PART OF THE CODE ********/
    /* THIS CODE WILL LOAD THE DATABASE OF USERS FROM THE FILE 
       AND GENERATE THE STARTING LINKED LIST.
    */
    FILE *csv_file = fopen("user_details.csv", "r");
    if (csv_file == NULL)
    {
        perror("Error opening the CSV file");
        return 1;
    }
    // Parse CSV data and create users
    user_t *users = read_CSV_and_create_users(csv_file, 50);

    fclose(csv_file);
    /******** DONT MODIFY THIS PART OF THE CODE ********/
    
    /* IMPORTANT: You must use the users linked list created in the code above. 
                  Any new users should be added to that linked list.
    */

    // Your solution goes here
    char username[50];
    char password[15];
    char content[256];
    int option, sub_option;
    printf("\n\n");
    printf("*****************************************\n");
    printf("\t Welcome to Text-Based Facebook\n");
    printf("*****************************************\n\n");

    do{
        print_menu();
        printf("Enter a choice\n");
        scanf("%d", &option);

        user_t *user = users;

        switch(option){
        case 1: // register a user
            printf("\nEnter a username: ");
            scanf("%s", username);
            printf("Enter a password that has max 15 characters: ");
            scanf("%s", password);
            if (find_user(user, username) != NULL)
            {
                printf("Please use another username, that is not in use: \n");
            }
            else
            {
                add_user(user, username, password);
                printf("******** User Added ! *********\n");
            }
            break;
        case 2:// log in 
            printf("\nEnter your username: ");
            scanf("%s", username);
            printf("\nEnter your password: ");
            scanf("%s", password);
            user_t *found_user = find_user(user, username);
            if (found_user != NULL){
                if (strcmp(found_user->password, password) == 0){
                    printf("\n--------------------------------\n");
                    printf("\t Welcome %s \n", username);
                    printf("----------------------------------\n\n");

                    do{
                        printf("\n***********************************************\n");
                        printf("\t\tMAIN MENU:\n");
                        printf("***********************************************\n");
                        printf("1. Register a new User\n");
                        printf("2. Manage a user's profile (change password)\n");
                        printf("3. Manage a user's posts (display/add/remove)\n");
                        printf("4. Manage a user's friends (display/add/remove)\n");
                        printf("5. Display All Posts\n");
                        printf("6. Exit\n");

                        printf("\nEnter your choice: ");
                        scanf("%d", &option);

                        user_t *user = users;
                        switch(option)
                        {
                        case 1: // register a user
                            printf("\nEnter a username: ");
                            scanf("%s", username);
                            printf("Enter a password that has max 15 characters: ");
                            scanf("%s", password);
                            if (find_user(user, username) != NULL)
                            {
                                printf("Please use another username, that is not in use: \n");
                            }
                            else
                            {
                                add_user(user, username, password);
                                printf("******** User Added ! *********\n");
                            }
                            break;
                        case 2: // Change password
                            printf("\nEnter username to update their password: ");
                            scanf("%s", username);

                            user = find_user(users, username);

                            if (user != NULL)
                            {
                                printf("\nEnter a new password that is upto 15 characters: ");
                                scanf("%s", password);
                                strcpy(user->password, password);
                                printf("\n**** Password changed! ****\n");
                            }
                            else
                            {
                                printf("\n\n-----------------------------------------------\n");
                                printf("\t\tUser not found.\n");
                                printf("-----------------------------------------------\n");
                            }
                            break;
                        case 3: //Manage a user's posts
                            printf("\nEnter username to manage their posts: ");
                            scanf("%s", username);
                            user = find_user(users, username);

                            do
                            {
                                if (user != NULL)
                                {
                                    printf("-----------------------------------------------\n");
                                    printf("\t\t%s's posts\n", user->username);
                                    display_user_posts(user);
                                    printf("------------------------------------------------\n");

                                    printf("\n1. Add a new user post\n");
                                    printf("2. Remove a users post\n");
                                    printf("3. Return to main menu\n");
                                    printf("\nYour choice: ");

                                    scanf("%d", &option);

                                    switch (option)
                                    {
                                    case 1: // Add new Post
                                        printf("Enter your post content: ");
                                        scanf(" %[^\n]s", content); // Read a line of text
                                        add_post(user, content);
                                        printf("Post added to your profile.\n");
                                        break;
                                    case 2: // Delete a post
                                        printf("Which post you want to delete? ");
                                        scanf("%d", &sub_option);
                                        delete_post(user, sub_option);
                                        break;
                                    case 3:
                                        break;
                                    default:
                                        printf("Invalid choice. Please try again.\n");
                                    }
                                }
                                else
                                {
                                    printf("\n\n-----------------------------------------------\n");
                                    printf("\t\tUser not found.\n");
                                    printf("-----------------------------------------------\n");
                                    break;
                                }
                            } while (option != 3);
                            break;
                        case 4: // Manage user's friends
                            printf("\nEnter username to manage their friends: ");
                            scanf("%s", username);
                            user = find_user(users, username);

                            do
                            {
                                if (user != NULL)
                                {
                                    printf("-----------------------------------------------\n");
                                    printf("\t\t%s's friends\n", user->username);
                                    printf("-----------------------------------------------\n");

                                    printf("\n1. Display all user's friends\n");
                                    printf("2. Add a new friend\n");
                                    printf("3. Delete a friend\n");
                                    printf("4. Display a friend's posts\n");
                                    printf("5. Return to main menu\n");
                                    printf("\nYour choice: ");

                                    scanf("%d", &option);
                                    int counter = 1;

                                    switch (option)
                                    {
                                    case 1:
                                        display_user_friends(user);
                                        break;
                                    case 2:
                                        printf("\nEnter a new friends' name: ");
                                        scanf("%s", username);
                                        counter = 1;
                                        add_friend(user, username);
                                        printf("Friend added to the list.\n");

                                        break;
                                    case 3:
                                        display_user_friends(user);
                                        printf("Enter a friend's name to delete:   ");
                                        scanf("%s", username);
                                        if(delete_friend(user, username) == false)
                                        {
                                            printf("Invalid friend name\n");
                                            break;
                                        }
                                        else
                                        {
                                            delete_friend(user, username);
                                            printf("\nFriend has been deleted\n");
                                            break;
                                        }
                                        break;
                                    case 4:
                                        printf("\nEnter friend's username: ");
                                        scanf("%s", username);
                                        user = find_user(users, username);
                                        if (user != NULL){
                                            printf("-----------------------------------\n");
                                            printf("\t  Your friend %s's posts \n", username);
                                            printf("-----------------------------------\n");
                                            display_user_posts(user);
                                            break;
                                        }
                                        else
                                        {
                                            printf("******User not found******\n");
                                            break;
                                        }
                                    default:
                                        printf("Invalid choice. Please try again.\n");
                                    }
                                }
                                else
                                {
                                    printf("\n\n-----------------------------------------------\n");
                                    printf("\t\tUser not found.\n");
                                    printf("-----------------------------------------------\n");
                                    break;
                                }
                            } while (option != 4);
                            break;
                        case 5: // Display All Posts
                            display_all_posts(users);
                            break;
                        case 6:
                            // Exit the program
                            printf("***********************************************\n");
                            printf("  Thank you for using Text-Based Facebook\n");
                            printf("\t\tGoodBye!\n");
                            printf("***********************************************\n\n");
                            break;

                        default:
                            printf("Invalid choice. Please try again.\n");
                        }
                    } while (option != 6);
                    break;
                }
                else{
                    printf("\nWrong password. Please try again. \n");
                }
            }
            else
            {
                printf("\nUser not found. Please check your username and try again: \n");

            }
            break;
        case 3: // Exit program
            printf("***********************************************\n");
            printf("  Thank you for using Text-Based Facebook\n");
            printf("\t\tGoodBye!\n");
            printf("***********************************************\n\n");
            break;
        default:
            printf("Invalid choice. Please try again.\n");
        };
    } while (option != 3);
    teardown(users);
}